<?php /* #?ini charset="utf-8"? 
# search for template operators in groupdocsassembly 
[TemplateSettings]
ExtensionAutoloadPath[]=groupdocsassembly
*/ ?>