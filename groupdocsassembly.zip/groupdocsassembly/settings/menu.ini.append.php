<?php /*
[NavigationPart]
Part[groupdocsnavigationpart]=GD Assembly
[TopAdminMenu]
Tabs[]=groupdocss
[Topmenu_groupdocss]
NavigationPartIdentifier=groupdocsnavigationpart
Name=Groupdocs Assembly
Tooltip=Managing the Newsletter list and sending emails
URL[]
URL[default]=groupdocsassembly/config
Enabled[]
Enabled[default]=true
Enabled[browse]=false
Enabled[edit]=false
Shown[]
Shown[default]=true
Shown[edit]=true
Shown[navigation]=true
Shown[browse]=true

*/ ?>